import datetime

from allauth import exceptions
from celery.bin.control import status
from django.contrib.auth import authenticate,login,logout

from django.db.migrations import serializer
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from requests import Response
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.decorators import api_view, renderer_classes
from rest_framework.permissions import AllowAny
from rest_framework.renderers import JSONRenderer
from rest_framework.views import APIView
from rest_framework import status, permissions
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from groceryapp.models import User, UserAuthTokens, Item, Order, RatingReview
from groceryapp.serializers import *
from rest_framework.response import Response


class CsrfExemptSessionAuthentication(SessionAuthentication):

    def enforce_csrf(self, request):
        return  # To not perform the csrf check previously happening

# Create your views here.


class Register(APIView):
    authentication_classes = (CsrfExemptSessionAuthentication, BasicAuthentication)
    permission_classes = [AllowAny]


    def post(self, request, *args, **kwargs):
        data = request.data
        serializer = RegisterSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        data['email'] = data['username']

        user_obj = User.objects.filter(username=data['username'])
        if not user_obj.exists():
            instance = User.objects.create_user(**data)
        else:
           return Response({"status":"data already exists"})
        return Response({"status": "success"})


class Login(APIView):
    authentication_classes = (CsrfExemptSessionAuthentication, BasicAuthentication)
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        data = request.data
        serializer = LoginSerializer(data=data)
        serializer.is_valid(raise_exception=True)

        username = serializer.validated_data['username']
        password = serializer.validated_data['password']

        user_obj = authenticate(username=username, password=password)

        if user_obj is not None:
            login(request, user_obj)

        else:
            raise exceptions.NotFound(detail="Invalid Username or Password.")

        token_obj = TokenObtainPairSerializer()
        token = token_obj.validate({"username": username, "password": password})
        access_token = token.get('access')
        refresh_token = token.get('refresh')

        user_auth_token_obj = UserAuthTokens.objects.filter(user_info=user_obj)
        if user_auth_token_obj.exists():
            user_auth_token_obj.update(access_token=access_token, refresh_token=refresh_token)
        else:
            UserAuthTokens.objects.create(user_info=user_obj, access_token=access_token, refresh_token=refresh_token)


        return Response({"status": status.HTTP_200_OK, "user_id": user_obj.id, "access_token": access_token,
                         "refresh_token": refresh_token})





'''
User Logout API
'''
@api_view(('GET',))
@renderer_classes([JSONRenderer])
def logout_view(request):
    logout(request)
    return Response({"status":status.HTTP_200_OK})


#item detail api---------
class ItemDetailView(APIView):

    def get(self, request,id, *args, **kwargs):


        obj = Item.objects.filter(id=id).values('name', 'price', 'description', 'category', 'varient')
        rating_obj = RatingReview.objects.filter(item=id).values('rating', 'review')
        data = {
            "obj": obj,
            "rating_obj": rating_obj
        }
        return Response({"status": "success", "data": data})


#OrderApi------------

class OrderView(APIView):
    authentication_classes = (CsrfExemptSessionAuthentication, BasicAuthentication)
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        data = {
            'quantity': request.data.get('quantity'),
            'item': request.data.get('item'),
        }
        serializer = OrderSerializer(data=data)
        if serializer.is_valid():
            item = serializer.validated_data['item']
            quantity = serializer.validated_data['quantity']
            item_obj=Item.objects.filter(name=item)
            if item_obj.exists():
                user = request.user
                order_date = datetime.date.today()
                Order.objects.create(user=user, quantity=quantity, item=item_obj[0], order_date=order_date)

                return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


#user_order_list-----------

class UserOrderDetailView(APIView):


    def get(self, request, *args, **kwargs):

        obj = Order.objects.filter().values('user__username', 'item__name', 'quantity', 'order_date')

        return Response({"status": "success", "data": obj})



#Rating & Review--------------
class RatingReviewView(APIView):
    authentication_classes = (CsrfExemptSessionAuthentication, BasicAuthentication)
    permission_classes = [AllowAny]
    def post(self, request, *args, **kwargs):
        data = {
            'rating': request.data.get('rating'),
            'review': request.data.get('review'),
            'item': request.data.get('item'),
        }
        serializer = RatingReviewSerializer(data=data)
        if serializer.is_valid():
            rating = serializer.validated_data['rating']
            review = serializer.validated_data['review']
            item = serializer.validated_data['item']
            item_obj = Item.objects.filter(name=item)
            if item_obj.exists():
                user = request.user
                rating_obj=RatingReview.objects.filter(item=item_obj[0])
                if rating_obj.exists():
                    rating_obj.update(rating=rating, review=review)

                else:
                    RatingReview.objects.create(user=user, rating=rating, review=review, item=item_obj[0])


                return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)





















