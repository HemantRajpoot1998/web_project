from django.apps import AppConfig


class GroceryappConfig(AppConfig):
    name = 'groceryapp'
