from django.contrib import admin
from django.urls import path
from .views import *

urlpatterns = [

    path('register', Register.as_view(), name = 'register'),
    path('Login', Login.as_view(), name='Login'),
    path('logout', logout_view, name='logout'),
    path('items/<int:id>', ItemDetailView.as_view(), name='items'),
    path('OrderView/', OrderView.as_view(), name='OrderView'),
    path('UserOrderDetail/', UserOrderDetailView.as_view(), name='UserOrderDetail'),
    path('RatingReview/', RatingReviewView.as_view(), name='RatingReview'),


]
