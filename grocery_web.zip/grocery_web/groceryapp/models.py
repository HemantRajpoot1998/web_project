from django.contrib.auth.models import AbstractUser
from django.db import models

# Create your models here.
class User(AbstractUser):
    GENDER_CHOICE = (
        ('male', 'male'),
        ('female', 'female'),
        ('unknown', 'unknown')
    )
    full_name = models.CharField(max_length=100, null=False, blank=False, default='unknown')
    gender = models.CharField(max_length=10, choices=GENDER_CHOICE, null=False, blank=False, default='unknown')
    country_code = models.CharField(max_length=5, null=False, blank=False)



    class Meta:
        db_table = 'user_info'


class UserAuthTokens(models.Model):
    user_info = models.OneToOneField(User, on_delete=models.CASCADE, related_name='user_tokens')
    access_token = models.TextField(blank=True, null=True)
    refresh_token = models.TextField(blank=True, null=True)
    added_on = models.DateTimeField(auto_now_add=True)
    updated_on = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'user_auth_tokens'





#------------------------------
class Variant(models.Model):
    name = models.CharField(max_length=255)
    added_on = models.DateTimeField(auto_now_add=True)

class Category(models.Model):
    name = models.CharField(max_length=255)
    added_on = models.DateTimeField(auto_now_add=True)

class Item(models.Model):
    name = models.CharField(max_length=255)
    price = models.FloatField(default=0)
    description = models.TextField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='category_item')
    varient = models.ForeignKey(Variant, on_delete=models.CASCADE, related_name='varient_item')
    is_active = models.BooleanField(default=True)
    added_on = models.DateTimeField(auto_now_add=True)





class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='user')
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name='item')
    quantity = models.FloatField(default=0)
    added_on = models.DateTimeField(auto_now_add=True)

class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='user_order')
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name='item_order')
    quantity = models.CharField(max_length=255)
    order_date = models.DateTimeField(auto_now_add=True)

USER_COURSE_RATING =(
    ('1', '1'),
    ('2', '2'),
    ('3', '3'),
    ('4', '4'),
    ('5', '5')

     )
class RatingReview(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='user_rating')
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name='item_rating')
    rating = models.CharField(max_length=1000, choices=USER_COURSE_RATING)
    review = models.CharField(max_length=1000)
    added_on = models.DateTimeField(auto_now_add=True)


















