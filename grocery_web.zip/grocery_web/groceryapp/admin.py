from django.contrib import admin

from groceryapp.models import *


# Register your models here.


class UserAdmin(admin.ModelAdmin):
    list_display = ['username','full_name','gender','country_code']


class UserAuthTokensAdmin(admin.ModelAdmin):
    list_display = ['user_info','access_token','refresh_token','added_on','updated_on']



class VariantAdmin(admin.ModelAdmin):
    list_display = ['name','added_on']

class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name','added_on']

class ItemAdmin(admin.ModelAdmin):
    list_display = ['id','name','price','description','category','varient','is_active','added_on']

class CartAdmin(admin.ModelAdmin):
    list_display = ['user','item','quantity','added_on']

class OrderAdmin(admin.ModelAdmin):
    list_display = ['user','item','quantity','order_date']

class RatingReviewAdmin(admin.ModelAdmin):
    list_display = ['user','item','rating','review','added_on']









admin.site.register(Variant,VariantAdmin)
admin.site.register(Category,CategoryAdmin)
admin.site.register(Item,ItemAdmin)
admin.site.register(Cart,CartAdmin)
admin.site.register(Order,OrderAdmin)
admin.site.register(RatingReview,RatingReviewAdmin)
admin.site.register(UserAuthTokens,UserAuthTokensAdmin)
