from rest_framework import serializers


class RegisterSerializer(serializers.Serializer):
    full_name = serializers.CharField(required = True)
    username = serializers.CharField(allow_blank = False,allow_null = False)
    password = serializers.CharField(allow_blank = False,allow_null = False)
    country_code = serializers.CharField(allow_blank = False,allow_null = False)




class LoginSerializer(serializers.Serializer):
    username = serializers.CharField(required = True)
    password = serializers.CharField(required = True)


class OrderSerializer(serializers.Serializer):
    item = serializers.CharField(required = True)
    quantity = serializers.CharField(required = True)


class RatingReviewSerializer(serializers.Serializer):
    rating = serializers.CharField(required = True)
    item = serializers.CharField(required=True)
    review = serializers.CharField(required=True)

